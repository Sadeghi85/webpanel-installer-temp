#!/bin/sh
echo $LD_LIBRARY_PATH | egrep "/opt/webpanel/lamp-x86_64/common" > /dev/null
if [ $? -ne 0 ] ; then
PATH="/opt/webpanel/lamp-x86_64/heroku/bin:/opt/webpanel/lamp-x86_64/ruby/bin:/opt/webpanel/lamp-x86_64/git/bin:/opt/webpanel/lamp-x86_64/sqlite/bin:/opt/webpanel/lamp-x86_64/php/bin:/opt/webpanel/lamp-x86_64/mysql/bin:/opt/webpanel/lamp-x86_64/apache2/bin:/opt/webpanel/lamp-x86_64/common/bin:$PATH"
export PATH
LD_LIBRARY_PATH="/opt/webpanel/lamp-x86_64/ruby/lib:/opt/webpanel/lamp-x86_64/git/lib:/opt/webpanel/lamp-x86_64/sqlite/lib:/opt/webpanel/lamp-x86_64/mysql/lib:/opt/webpanel/lamp-x86_64/apache2/lib:/opt/webpanel/lamp-x86_64/common/lib:$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH
fi

##### RUBY ENV #####
GEM_HOME="/opt/webpanel/lamp-x86_64/ruby/lib/ruby/gems/2.0.0"
GEM_PATH="/opt/webpanel/lamp-x86_64/ruby/lib/ruby/gems/2.0.0"
RUBY_HOME="/opt/webpanel/lamp-x86_64/ruby"
RUBYLIB="/opt/webpanel/lamp-x86_64/ruby/lib/ruby/site_ruby/2.0.0:/opt/webpanel/lamp-x86_64/ruby/lib/ruby/site_ruby/2.0.0/x86_64-linux:/opt/webpanel/lamp-x86_64/ruby/lib/ruby/site_ruby/:/opt/webpanel/lamp-x86_64/ruby/lib/ruby/vendor_ruby/2.0.0:/opt/webpanel/lamp-x86_64/ruby/lib/ruby/vendor_ruby/2.0.0/x86_64-linux:/opt/webpanel/lamp-x86_64/ruby/lib/ruby/vendor_ruby/:/opt/webpanel/lamp-x86_64/ruby/lib/ruby/2.0.0:/opt/webpanel/lamp-x86_64/ruby/lib/ruby/2.0.0/x86_64-linux:/opt/webpanel/lamp-x86_64/ruby/lib/ruby/:/opt/webpanel/lamp-x86_64/ruby/lib"
BUNDLE_CONFIG="/opt/webpanel/lamp-x86_64/ruby/.bundler/config"
export GEM_HOME
export GEM_PATH
export RUBY_HOME
export RUBYLIB
export BUNDLE_CONFIG
##### GIT ENV #####
GIT_EXEC_PATH=/opt/webpanel/lamp-x86_64/git/libexec/git-core/
export GIT_EXEC_PATH
GIT_TEMPLATE_DIR=/opt/webpanel/lamp-x86_64/git/share/git-core/templates
export GIT_TEMPLATE_DIR
GIT_SSL_CAINFO=/opt/webpanel/lamp-x86_64/common/openssl/certs/curl-ca-bundle.crt
export GIT_SSL_CAINFO

##### SQLITE ENV #####
			
##### IMAGEMAGICK ENV #####
MAGICK_HOME="/opt/webpanel/lamp-x86_64/common"
export MAGICK_HOME

MAGICK_CONFIGURE_PATH="/opt/webpanel/lamp-x86_64/common/lib/ImageMagick-6.7.5/config:/opt/webpanel/lamp-x86_64/common/"
export MAGICK_CONFIGURE_PATH

MAGICK_CODER_MODULE_PATH="/opt/webpanel/lamp-x86_64/common/lib/ImageMagick-6.7.5/modules-Q16/coders"
export MAGICK_CODER_MODULE_PATH

GS_LIB="/opt/webpanel/lamp-x86_64/common/share/ghostscript/fonts"
export GS_LIB
LDAPCONF=/opt/webpanel/lamp-x86_64/common/etc/openldap/ldap.conf
export LDAPCONF
##### PHP ENV #####
		    
##### MYSQL ENV #####

##### APACHE ENV #####

##### FREETDS ENV #####
FREETDSCONF=/opt/webpanel/lamp-x86_64/common/etc/freetds.conf
export FREETDSCONF
##### CURL ENV #####
CURL_CA_BUNDLE=/opt/webpanel/lamp-x86_64/common/openssl/certs/curl-ca-bundle.crt
export CURL_CA_BUNDLE
##### SSL ENV #####
SSL_CERT_FILE=/opt/webpanel/lamp-x86_64/common/openssl/certs/curl-ca-bundle.crt
export SSL_CERT_FILE
OPENSSL_CONF=/opt/webpanel/lamp-x86_64/common/openssl/openssl.cnf
export OPENSSL_CONF


. /opt/webpanel/lamp-x86_64/scripts/build-setenv.sh
