#!/bin/sh
LDFLAGS="-L/opt/webpanel/lamp-x86_64/common/lib $LDFLAGS"
export LDFLAGS
CFLAGS="-I/opt/webpanel/lamp-x86_64/common/include/ImageMagick -I/opt/webpanel/lamp-x86_64/common/include $CFLAGS"
export CFLAGS
		    
PKG_CONFIG_PATH="/opt/webpanel/lamp-x86_64/common/lib/pkgconfig"
export PKG_CONFIG_PATH
