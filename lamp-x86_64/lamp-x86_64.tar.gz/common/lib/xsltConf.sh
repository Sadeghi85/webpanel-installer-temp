#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/opt/webpanel/lamp-x86_64/common/lib"
XSLT_LIBS="-lxslt  -L/opt/webpanel/lamp-x86_64/common/lib -lxml2 -lz -liconv -lm -ldl -lm -lrt"
XSLT_INCLUDEDIR="-I/opt/webpanel/lamp-x86_64/common/include"
MODULE_VERSION="xslt-1.1.28"
