#!/bin/sh
echo $LD_LIBRARY_PATH | egrep "/opt/webpanel/lamp-i686/common" > /dev/null
if [ $? -ne 0 ] ; then
PATH="/opt/webpanel/lamp-i686/heroku/bin:/opt/webpanel/lamp-i686/ruby/bin:/opt/webpanel/lamp-i686/git/bin:/opt/webpanel/lamp-i686/sqlite/bin:/opt/webpanel/lamp-i686/php/bin:/opt/webpanel/lamp-i686/mysql/bin:/opt/webpanel/lamp-i686/apache2/bin:/opt/webpanel/lamp-i686/common/bin:$PATH"
export PATH
LD_LIBRARY_PATH="/opt/webpanel/lamp-i686/ruby/lib:/opt/webpanel/lamp-i686/git/lib:/opt/webpanel/lamp-i686/sqlite/lib:/opt/webpanel/lamp-i686/mysql/lib:/opt/webpanel/lamp-i686/apache2/lib:/opt/webpanel/lamp-i686/common/lib:$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH
fi

##### RUBY ENV #####
GEM_HOME="/opt/webpanel/lamp-i686/ruby/lib/ruby/gems/2.0.0"
GEM_PATH="/opt/webpanel/lamp-i686/ruby/lib/ruby/gems/2.0.0"
RUBY_HOME="/opt/webpanel/lamp-i686/ruby"
RUBYLIB="/opt/webpanel/lamp-i686/ruby/lib/ruby/site_ruby/2.0.0:/opt/webpanel/lamp-i686/ruby/lib/ruby/site_ruby/2.0.0/i686-linux:/opt/webpanel/lamp-i686/ruby/lib/ruby/site_ruby/:/opt/webpanel/lamp-i686/ruby/lib/ruby/vendor_ruby/2.0.0:/opt/webpanel/lamp-i686/ruby/lib/ruby/vendor_ruby/2.0.0/i686-linux:/opt/webpanel/lamp-i686/ruby/lib/ruby/vendor_ruby/:/opt/webpanel/lamp-i686/ruby/lib/ruby/2.0.0:/opt/webpanel/lamp-i686/ruby/lib/ruby/2.0.0/i686-linux:/opt/webpanel/lamp-i686/ruby/lib/ruby/:/opt/webpanel/lamp-i686/ruby/lib"
BUNDLE_CONFIG="/opt/webpanel/lamp-i686/ruby/.bundler/config"
export GEM_HOME
export GEM_PATH
export RUBY_HOME
export RUBYLIB
export BUNDLE_CONFIG

CONFIGURE_ARGS="--with-cflags='-m32' --with-ldflags='-m32'"
export CONFIGURE_ARGS
##### GIT ENV #####
GIT_EXEC_PATH=/opt/webpanel/lamp-i686/git/libexec/git-core/
export GIT_EXEC_PATH
GIT_TEMPLATE_DIR=/opt/webpanel/lamp-i686/git/share/git-core/templates
export GIT_TEMPLATE_DIR
GIT_SSL_CAINFO=/opt/webpanel/lamp-i686/common/openssl/certs/curl-ca-bundle.crt
export GIT_SSL_CAINFO

##### SQLITE ENV #####
			
##### IMAGEMAGICK ENV #####
MAGICK_HOME="/opt/webpanel/lamp-i686/common"
export MAGICK_HOME

MAGICK_CONFIGURE_PATH="/opt/webpanel/lamp-i686/common/lib/ImageMagick-6.7.5/config:/opt/webpanel/lamp-i686/common/"
export MAGICK_CONFIGURE_PATH

MAGICK_CODER_MODULE_PATH="/opt/webpanel/lamp-i686/common/lib/ImageMagick-6.7.5/modules-Q16/coders"
export MAGICK_CODER_MODULE_PATH

GS_LIB="/opt/webpanel/lamp-i686/common/share/ghostscript/fonts"
export GS_LIB
LDAPCONF=/opt/webpanel/lamp-i686/common/etc/openldap/ldap.conf
export LDAPCONF
##### PHP ENV #####
		    
##### MYSQL ENV #####

##### APACHE ENV #####

##### FREETDS ENV #####
FREETDSCONF=/opt/webpanel/lamp-i686/common/etc/freetds.conf
export FREETDSCONF
##### CURL ENV #####
CURL_CA_BUNDLE=/opt/webpanel/lamp-i686/common/openssl/certs/curl-ca-bundle.crt
export CURL_CA_BUNDLE
##### SSL ENV #####
SSL_CERT_FILE=/opt/webpanel/lamp-i686/common/openssl/certs/curl-ca-bundle.crt
export SSL_CERT_FILE
OPENSSL_CONF=/opt/webpanel/lamp-i686/common/openssl/openssl.cnf
export OPENSSL_CONF


. /opt/webpanel/lamp-i686/scripts/build-setenv.sh
