#!/bin/sh
LDFLAGS="-L/opt/webpanel/lamp-i686/common/lib $LDFLAGS"
export LDFLAGS
CFLAGS="-I/opt/webpanel/lamp-i686/common/include/ImageMagick -I/opt/webpanel/lamp-i686/common/include $CFLAGS"
export CFLAGS
		    
PKG_CONFIG_PATH="/opt/webpanel/lamp-i686/common/lib/pkgconfig"
export PKG_CONFIG_PATH
