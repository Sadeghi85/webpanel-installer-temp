#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/opt/webpanel/lamp-i686/common/lib"
XML2_LIBS="-lxml2 -lz   -liconv -lm "
XML2_INCLUDEDIR="-I/opt/webpanel/lamp-i686/common/include/libxml2"
MODULE_VERSION="xml2-2.9.1"

